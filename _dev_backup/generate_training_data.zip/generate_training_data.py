# -*- coding: utf-8 -*-
"""
합성 데이터 생성기 (END 라벨 포함)
Data Set v1_G14-1.json 형식으로 출력
"""

import json
import random
import os

# ==========================================
# A. 단어 데이터베이스 (DB)
# ==========================================

locations = [
    "Gangnam Station", "Seoul Station", "Times Square", "Building 301", "Room 101",
    "the cafeteria", "Starbucks", "the library", "Central Park", "the lobby",
    "Conference Room A", "the gym", "my office", "New York", "London",
    "the meeting room", "Zoom", "Google Meet", "Teams", "the office",
    "Room 205", "the auditorium", "Main Hall", "Building A", "the rooftop"
]

events = [
    "Team meeting", "Project deadline", "Lunch with Sarah", "Dinner party",
    "Doctor's appointment", "Dentist appointment", "Job interview", "Final exam",
    "Midterm exam", "Soccer match", "Baseball game", "F1 Grand Prix",
    "Birthday party", "Wedding ceremony", "Workshop", "Seminar", "Hackathon",
    "Conference call", "Training session", "Code review", "Sprint planning",
    "Client meeting", "Product demo", "Team lunch", "Annual review"
]

# 시작 날짜
start_dates = [
    "tomorrow", "today", "next Monday", "this Friday", "January 15th",
    "March 10th", "December 25th", "next week", "this weekend",
    "August 1st", "September 20th", "November 5th", "next Sunday",
    "this Thursday", "next Tuesday", "February 14th", "April 1st"
]

# 종료 날짜 (기간 표현용)
end_dates = [
    "next Friday", "the 20th", "December 31st", "the end of the month",
    "Sunday", "next week Friday", "the following Monday", "March 15th",
    "the 25th", "next Thursday", "April 5th", "the weekend"
]

# 시작 시간
start_times = [
    "2 PM", "10 AM", "7:00 PM", "noon", "9:30 AM",
    "6 o'clock", "3:15 PM", "8 AM", "1 PM", "4:30 PM",
    "11 AM", "5 PM", "10:00 AM", "2:30 PM", "9 AM"
]

# 종료 시간
end_times = [
    "4 PM", "12 PM", "9:00 PM", "5 PM", "11:30 AM",
    "8 o'clock", "6:00 PM", "10 AM", "3 PM", "7:30 PM",
    "1 PM", "6 PM", "12:00 PM", "5:30 PM", "11 AM"
]

# ==========================================
# B. 문장 템플릿 (START + END 포함)
# ==========================================

# START만 있는 템플릿
start_only_templates = [
    {"template": "I have a {event} at {loc} {start_date} at {start_time}.",
     "has": ["event", "loc", "start_date", "start_time"]},
    {"template": "{start_date}, there is a {event} at {start_time}.",
     "has": ["start_date", "event", "start_time"]},
    {"template": "Let's meet at {loc} at {start_time} for {event}.",
     "has": ["loc", "start_time", "event"]},
    {"template": "Reminder: {event} is {start_date} at {start_time}.",
     "has": ["event", "start_date", "start_time"]},
    {"template": "Please attend the {event} at {loc}.",
     "has": ["event", "loc"]},
    {"template": "My {event} starts at {start_time} {start_date}.",
     "has": ["event", "start_time", "start_date"]},
    {"template": "Go to {loc} {start_date} for the {event}.",
     "has": ["loc", "start_date", "event"]},
    {"template": "{event} will be held at {loc} on {start_date}.",
     "has": ["event", "loc", "start_date"]},
    {"template": "Schedule a {event} at {start_time}.",
     "has": ["event", "start_time"]},
    {"template": "{start_date} is the deadline for {event}.",
     "has": ["start_date", "event"]},
]

# START + END 포함 템플릿 (핵심!)
start_end_templates = [
    {"template": "Meeting from {start_time} to {end_time} {start_date} at {loc}.",
     "has": ["start_time", "end_time", "start_date", "loc"]},
    {"template": "The {event} runs from {start_date} to {end_date}.",
     "has": ["event", "start_date", "end_date"]},
    {"template": "{event} at {loc} from {start_time} until {end_time}.",
     "has": ["event", "loc", "start_time", "end_time"]},
    {"template": "Workshop from {start_time} to {end_time} on {start_date}.",
     "has": ["start_time", "end_time", "start_date"]},
    {"template": "The conference is scheduled from {start_date} through {end_date}.",
     "has": ["start_date", "end_date"]},
    {"template": "{event} starts at {start_time} and ends at {end_time}.",
     "has": ["event", "start_time", "end_time"]},
    {"template": "Book {loc} from {start_time} to {end_time} for {event}.",
     "has": ["loc", "start_time", "end_time", "event"]},
    {"template": "Training session from {start_date} to {end_date} at {loc}.",
     "has": ["start_date", "end_date", "loc"]},
    {"template": "The {event} is from {start_time} to {end_time} at {loc}.",
     "has": ["event", "start_time", "end_time", "loc"]},
    {"template": "Please block {start_date} to {end_date} for the {event}.",
     "has": ["start_date", "end_date", "event"]},
    {"template": "Join us from {start_time} until {end_time} for the {event}.",
     "has": ["start_time", "end_time", "event"]},
    {"template": "Available from {start_time} to {end_time} on {start_date}.",
     "has": ["start_time", "end_time", "start_date"]},
]

# ==========================================
# C. 합성 데이터 생성 함수
# ==========================================

def generate_synthetic_data(num_start_only=300, num_start_end=200):
    """합성 데이터 생성 (딕셔너리 형식)"""
    dataset = []
    current_id = 10001  # 기존 데이터와 ID 충돌 방지
    
    print("🔄 합성 데이터 생성 중...")
    
    # START만 있는 데이터 생성
    for _ in range(num_start_only):
        template_info = random.choice(start_only_templates)
        template = template_info["template"]
        has_fields = template_info["has"]
        
        # 랜덤 값 선택
        values = {
            "event": random.choice(events),
            "loc": random.choice(locations),
            "start_date": random.choice(start_dates),
            "start_time": random.choice(start_times),
        }
        
        # 템플릿에 값 채우기
        text = template.format(**values)
        
        # 데이터 레코드 생성
        record = {
            "ID": current_id,
            "Text": text,
            "Date_Entity": values["start_date"] if "start_date" in has_fields else "",
            "Time_Entity": values["start_time"] if "start_time" in has_fields else "",
            "Location_Entity": values["loc"] if "loc" in has_fields else "",
            "Event_Entity": values["event"] if "event" in has_fields else "",
            "End_Date_Entity": "",
            "End_Time_Entity": "",
            "Notes": "synthetic_start_only"
        }
        
        dataset.append(record)
        current_id += 1
    
    print(f"  ✅ START 전용 데이터 {num_start_only}개 생성")
    
    # START + END 데이터 생성
    for _ in range(num_start_end):
        template_info = random.choice(start_end_templates)
        template = template_info["template"]
        has_fields = template_info["has"]
        
        # 랜덤 값 선택
        values = {
            "event": random.choice(events),
            "loc": random.choice(locations),
            "start_date": random.choice(start_dates),
            "end_date": random.choice(end_dates),
            "start_time": random.choice(start_times),
            "end_time": random.choice(end_times),
        }
        
        # 템플릿에 값 채우기
        text = template.format(**values)
        
        # 데이터 레코드 생성
        record = {
            "ID": current_id,
            "Text": text,
            "Date_Entity": values["start_date"] if "start_date" in has_fields else "",
            "Time_Entity": values["start_time"] if "start_time" in has_fields else "",
            "Location_Entity": values["loc"] if "loc" in has_fields else "",
            "Event_Entity": values["event"] if "event" in has_fields else "",
            "End_Date_Entity": values["end_date"] if "end_date" in has_fields else "",
            "End_Time_Entity": values["end_time"] if "end_time" in has_fields else "",
            "Notes": "synthetic_with_end"
        }
        
        dataset.append(record)
        current_id += 1
    
    print(f"  ✅ START+END 데이터 {num_start_end}개 생성")
    
    return dataset


# ==========================================
# D. 메인 실행
# ==========================================

if __name__ == "__main__":
    print("=" * 50)
    print("📊 NER 학습용 합성 데이터 생성기")
    print("=" * 50)
    
    # 1. 합성 데이터 생성
    synthetic_data = generate_synthetic_data(num_start_only=300, num_start_end=200)
    print(f"\n📈 총 합성 데이터: {len(synthetic_data)}개")
    
    # 2. 기존 데이터 로드 및 병합 (선택적)
    existing_file = 'Data Set v1_G14-1.json'
    final_dataset = synthetic_data.copy()
    
    if os.path.exists(existing_file):
        try:
            with open(existing_file, 'r', encoding='utf-8') as f:
                real_data = json.load(f)
            
            # 기존 데이터에 End 필드가 없으면 추가
            for record in real_data:
                if "End_Date_Entity" not in record:
                    record["End_Date_Entity"] = ""
                if "End_Time_Entity" not in record:
                    record["End_Time_Entity"] = ""
            
            print(f"\n📂 기존 파일 '{existing_file}' 로드 성공! ({len(real_data)}개)")
            
            # 데이터 병합
            final_dataset = synthetic_data + real_data
            print(f"🔗 데이터 병합 완료: 합성({len(synthetic_data)}) + 실제({len(real_data)}) = 총 {len(final_dataset)}개")
            
        except Exception as e:
            print(f"⚠️ 기존 파일 로드 중 오류 발생: {e}")
            print("👉 합성 데이터만 사용합니다.")
    else:
        print(f"\n⚠️ '{existing_file}' 파일이 없습니다. 합성 데이터만 사용합니다.")
    
    # 3. 데이터 섞기
    random.shuffle(final_dataset)
    
    # 4. 저장
    output_file = 'synthetic_training_data.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(final_dataset, f, ensure_ascii=False, indent=2)
    
    print(f"\n🎉 최종 데이터셋 저장 완료!")
    print(f"   📁 파일명: {output_file}")
    print(f"   📊 총 데이터 수: {len(final_dataset)}개")
    
    # 5. 예시 출력
    print("\n📋 예시 데이터:")
    for i, example in enumerate(final_dataset[:3]):
        print(f"\n--- 예시 {i+1} ---")
        print(f"  Text: {example['Text']}")
        print(f"  Date: {example['Date_Entity']}")
        print(f"  Time: {example['Time_Entity']}")
        print(f"  End Date: {example.get('End_Date_Entity', '')}")
        print(f"  End Time: {example.get('End_Time_Entity', '')}")
        print(f"  Location: {example['Location_Entity']}")
        print(f"  Event: {example['Event_Entity']}")
    
    print("\n" + "=" * 50)
